<?php include "templates/header.php" ?> 
<?php include "templates/nav.php" ?> 
    <!-- Contact Page Start -->
  <?php include "templates/contactsec.php"; ?>
    <!-- Contact Page Ends Here -->



    <?php include "templates/subs.php" ?> 
<?php include "templates/footer.php" ?>