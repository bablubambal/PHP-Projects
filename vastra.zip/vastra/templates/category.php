   <!-- Featured Starts Here -->
   <div class="featured-items">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <div class="line-dec"></div>
              <h1>Shop By Category : </h1>
            </div>
          </div>
          <div class="col-md-12">
            <div class="owl-carousel owl-theme">
              <a href="category.php?category=kurthi">
                <div class="featured-item">
                  <img height="300px" width="300px" src="assets/images/c-1.jpeg" alt="Item 1">
                  <h4>Kurtis</h4>
                  <h6></h6>
                </div>
              </a>
              <a href="category.php?category=dresses">
                <div class="featured-item">
                  <img  height="300px" width="300px"  src="assets/images/c-2.jpeg" alt="Item 2">
                  <h4>Dresses</h4>
                  <h6></h6>
                </div>
              </a>
              <a href="category.php?category=suits">
                <div class="featured-item">
                  <img  height="300px" width="300px"  src="assets/images/c-3.jpeg" alt="Item 3">
                  <h4>Suits</h4>
                  <!-- <h6>$35.00</h6> -->
                </div>
              </a>
              <a href="category.php?category=saree">
                <div class="featured-item">
                  <img  height="300px" width="300px"  src="assets/images/c-4.jpeg" alt="Item 4">
                  <h4>Sarees</h4>
                  <!-- <h6>$45.00</h6> -->
                </div>
              </a>
             
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Featred Ends Here -->
