 <!-- banner section start -->
 <div class="banner_section layout_padding">
         <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <div class="container">
                     <div class="row">
                        <div class="col-sm-6">
                           <h1 class="banner_taital">Ceramic <br>Studio</h1>
                           <p class="banner_text">Personalize your space with our unique ceramics.</p>
                           <div class="read_bt"><a href="shop.php">Buy Now</a></div>
                        </div>
                        <div class="col-sm-6">
                           <div class="banner_img"><img src="images/banner-img.png"></div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="carousel-item">
                  <div class="container">
                     <div class="row">
                        <div class="col-sm-6">
                        <h1 class="banner_taital">Ceramic <br>Studio</h1>
                        <p class="banner_text">Personalize your space with our unique ceramics.</p>
                           <div class="read_bt"><a href="shop.php">Buy Now</a></div>
                        </div>
                        <div class="col-sm-6">
                           <div class="banner_img"><img src="images/banner-img.png"></div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="carousel-item">
                  <div class="container">
                     <div class="row">
                        <div class="col-sm-6">
                        <h1 class="banner_taital">Ceramic <br>Studio</h1>
                        <p class="banner_text">Create memories with our bespoke pottery</p>
                           <div class="read_bt"><a href="shop.php">Buy Now</a></div>
                        </div>
                        <div class="col-sm-6">
                           <div class="banner_img"><img src="images/banner-img.png"></div>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="carousel-item">
                  <div class="container">
                     <div class="row">
                        <div class="col-sm-6">
                        <h1 class="banner_taital">Ceramic <br>Studio</h1>
                        <p class="banner_text">Handmade ceramics, tailored to your style.</p>
                           <div class="read_bt"><a href="shop.php">Buy Now</a></div>
                        </div>
                        <div class="col-sm-6">
                           <div class="banner_img"><img src="images/banner-img.png"></div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!-- banner section end -->