  <!-- product section start -->
  <div class="product_section layout_padding">
      <div class="container">
          <div class="row">
              <div class="col-sm-12">
                  <h1 class="product_taital">Our Category</h1>
                  <p class="product_text">Search Products via Category</p>
              </div>
          </div>
          <div class="product_section_2 layout_padding">
              <div class="row">
                  <div class="col-lg-3 col-sm-6">
                      <a href="category.php?category=bowls">
                          <div class="product_box">
                              <h4 class="bursh_text">Bowls</h4>
                              <!-- <p class="lorem_text">incididunt ut labore et dolore magna aliqua. Ut enim </p> -->
                              <img src="images/cat-1.jpeg" class="image_1">

                          </div>
                      </a>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                  <a href="category.php?category=vase">
                          <div class="product_box">
                              <h4 class="bursh_text">Vase</h4>
                              <!-- <p class="lorem_text">incididunt ut labore et dolore magna aliqua. Ut enim </p> -->
                              <img src="images/cat-2.jpeg" class="image_1">

                          </div>
                      </a>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                  <a href="category.php?category=glasses">
                          <div class="product_box">
                              <h4 class="bursh_text">Glasses</h4>
                              <!-- <p class="lorem_text">incididunt ut labore et dolore magna aliqua. Ut enim </p> -->
                              <img src="images/cat-3.jpeg" class="image_1">

                          </div>
                      </a>
                  </div>
                  <div class="col-lg-3 col-sm-6">
                  <a href="category.php?category=plates">
                          <div class="product_box">
                              <h4 class="bursh_text">Plates</h4>
                              <!-- <p class="lorem_text">incididunt ut labore et dolore magna aliqua. Ut enim </p> -->
                              <img src="images/cat-4.jpeg" class="image_1">

                          </div>
                      </a>
                  </div>
              </div>

          </div>
      </div>
  </div>
  <!-- product section end -->