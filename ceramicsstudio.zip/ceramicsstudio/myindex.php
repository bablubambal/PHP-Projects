
  
    <?php include("templates/nav.php"); ?>
    <?php include("templates/banner.php"); ?>
    <?php include("templates/products.php"); ?>
    <?php include("templates/about.php"); ?>
  
    <?php include("templates/customer.php"); ?>
    <?php include("templates/contact.php"); ?>
    <?php include("templates/footer.php"); ?>
     
    
    
     
   