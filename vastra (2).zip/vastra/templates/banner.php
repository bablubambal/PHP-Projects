 <!-- Banner Starts Here -->
 <div class="banner">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="caption">
              <h2>Vastra E Commerce Store..</h2>
              <div class="line-dec"></div>
              <p>
              At Vastra, we believe that fashion should be accessible to everyone, regardless of their size, shape, or background. That's why we offer a range of sizes, styles, and colors to suit every taste and occasion.  
              .</p>
              <div class="main-button">
                <a href="shop.php">Buy Now!</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Banner Ends Here -->