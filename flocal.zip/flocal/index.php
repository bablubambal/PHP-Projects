<?php include "templates/header.php"; ?>
<?php include "templates/slider.php"; ?>

     
 <?php include "templates/aboutsec.php"; ?>
     
<?php include "templates/plant.php"; ?>
    
     
<?php include "templates/footer.php"; ?>