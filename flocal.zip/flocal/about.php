<?php  include "templates/header.php"; ?>
<?php include "templates/slider.php"; ?>
<?php include "templates/aboutsec.php"; ?>



  <!-- end about section -->
<?php include "templates/footer.php"; ?>