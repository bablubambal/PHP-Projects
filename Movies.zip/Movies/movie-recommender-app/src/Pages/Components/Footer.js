// Footer Component
import "./styles/Footer.css";

const Footer = () => {
    return (
        <footer>
            <div className="footer">
              
                <div id="row1" className="row">
                    © Developed By Movie Adda
                </div>
            </div>
        </footer>
    );
};

export default Footer;
