	
	<?php include "temp/basichead.php" ; ?>	
	<?php include "temp/hero.php" ; ?>
	<?php include "temp/products.php" ; ?>
		
	
		  
     
		

		
		<!--sofa-collection start -->
		<section id="sofa-collection">
			<div class="owl-carousel owl-theme" id="collection-carousel">
				<div class="sofa-collection collectionbg1">
					<div class="container">
						<div class="sofa-collection-txt">
							<h2>WEFTING</h2>
							<p>
							WEFTING Handloom Company is a unique and innovative brand that combines the art of handloom with the modern technique of wefting to create custom-made hair extensions.  
							</p>
							<div class="sofa-collection-price">
								<h4>strting from <span>₹ 199</span></h4>
							</div>
                            <!-- onclick="window.location.href='#'" -->
							<!-- <button class="btn-cart welcome-add-cart sofa-collection-btn"  >
								view more
							</button> -->
						</div>
					</div>	
				</div><!--/.sofa-collection-->
				<!-- <div class="sofa-collection collectionbg2">
					<div class="container">
						<div class="sofa-collection-txt">
							<h2>unlimited dainning table collection</h2>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
							</p>
							<div class="sofa-collection-price">
								<h4>strting from <span>$ 299</span></h4>
							</div>
							<button class="btn-cart welcome-add-cart sofa-collection-btn" onclick="window.location.href='#'">
								view more
							</button>
						</div>
					</div>
				</div> -->
				
			</div>
			<!--/.collection-carousel-->

		</section><!--/.sofa-collection-->
		<!--sofa-collection end -->

		

		
		<?php include "temp/newsletter.php" ; ?>	

		<?php include "temp/footer.php" ; ?>	





  

 
  



 


