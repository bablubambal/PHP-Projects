  <!-- about section -->
  <section class="about_section layout_padding">
    <div class="about_container">
      <div class="container">
        <div class="detail">
          <h2 class="custom_heading">
            About Us
          </h2>
          <p>
            Garden of Dreams is a one-stop-shop for all your gardening needs, offering a wide range of high-quality plants, seeds, and pesticides
          </p>
          <div>
            <a href="">
              Read More
            </a>
          </div>
        </div>
        <div class="detail-2">
          <p>
            It is a long established fact that a reader will be distracted by the readable content of a page when
            looking at its layout. The point of g it
          </p>
        </div>
      </div>
    </div>
  </section>


  <!-- end about section -->