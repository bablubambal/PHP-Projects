  <!-- info section -->
  <section class="info_section layout_padding">
    <div class="container layout_padding-top  layout_padding2-bottom">
      <div class="logo-box">
        <a href="index.html">
          <img src="images/log.png" alt="">
        </a>
      </div>
      <div class="info_items">
        <a href="">
          <div class="item ">
            <div class="img-box box-1">
              <img src="images/location-white.png" alt="" />
            </div>
            <div class="detail-box">
              <p>
               Dreams of Garden Delivers Plants At Your Door Step
              </p>
            </div>
          </div>
        </a>
        <a href="">
          <div class="item ">
            <div class="img-box box-3">
              <img src="images/envelope-white.png" alt="" />
            </div>
            <div class="detail-box">
              <p>
                gardenofdreams@gmail.com
              </p>
            </div>
          </div>
        </a>
        <a href="">
          <div class="item ">
            <div class="img-box box-2">
              <img src="images/telephone-white.png" alt="" />
            </div>
            <div class="detail-box">
              <p>
                +91 6304 408 506
              </p>
            </div>
          </div>
        </a>

      </div>
    </div>
  </section>

  <!-- end info_section -->

  <!-- footer section -->
  <section class="container-fluid footer_section">
    <p>
      &copy; 2023 Garden of Dreams
     
    </p>
  </section>
  <!-- footer section -->

  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
</body>

</html>