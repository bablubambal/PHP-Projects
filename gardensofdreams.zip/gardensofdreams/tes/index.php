

<?php include "navbar.php"; ?>
<?php include "herosec.php"; ?>

<?php include "aboutsec.php"; ?>

  <?php include "contactsec.php"; ?>
 



<?php include "clientsec.php"; ?>

<?php include "foot.php"; ?>

