    <!-- end header section -->
    <!-- hero section -->
    <section class="hero_section">
      <div class="hero_detail">
        <h1>
          <span>
            b
          </span>
          <span>
            u
          </span>
          <span>
            y
          </span>
          <span>
            p
          </span>
          <span>
            l
          </span>
          <span>
            a
          </span>
          <span>
            n
          </span>
          <span>
            t
          </span>
            <span>
            s
          </span>
        </h1>
        <h3>
         Shop Naturally
          </h2>
      </div>
      <div class="hero_btn-box">
        <a href="shop.php">
         Buy Plants
        </a>
      </div>
    </section>
    <!-- end hero section -->
  </div>
  <!-- end hero area -->