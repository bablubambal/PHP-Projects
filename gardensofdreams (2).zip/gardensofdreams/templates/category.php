   <!-- Featured Starts Here -->
   <div class="featured-items">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <div class="line-dec"></div>
              <!-- <h1>Shop By Category : </h1> -->
            </div>
          </div>
          <div class=" col-lg-4 col-md-6 col-sm-12">
          <a href="category.php?category=plants"  >
                <div class="featured-item rounded">
                  <img height="300px" width="300px" src="assets/images/plant.jpg" alt="Item 1">
                  <h4>Plants</h4>
                  <h6></h6>
                </div>
              </a>
          </div>
          <div class=" col-lg-4 col-md-6 col-sm-12">
          <a href="category.php?category=pesticide" >
                <div class="featured-item">
                  <img  height="300px" width="300px"  src="assets/images/pesticide.jpg" alt="Item 2">
                  <h4>Pesticide</h4>
                  <h6></h6>
                </div>
              </a>
          </div>
          <div class=" col-lg-4 col-md-6 col-sm-12">
          <a href="category.php?category=seeds"  >
                <div class="featured-item">
                  <img  height="300px" width="300px"  src="assets/images/seeds.jpg" alt="Item 3">
                  <h4>Seeds</h4>
                  <h6></h6>
                </div>
              </a>
          </div>
            
              
             
             
              
          
        </div>
      </div>
    </div>
    <!-- Featred Ends Here -->
