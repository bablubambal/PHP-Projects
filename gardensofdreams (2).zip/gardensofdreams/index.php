
  

 




<?php include "templates/header.php" ?> 

<?php include "templates/nav.php" ?> 
<?php include "templates/banner.php" ?> 

<?php include "templates/category.php" ?>
<?php include "templates/features.php" ?> 

<?php include "templates/subs.php" ?> 
<?php include "templates/footer.php" ?> 