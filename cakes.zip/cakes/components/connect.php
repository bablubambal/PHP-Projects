<?php

$db_name = 'mysql:host=localhost;dbname=cakes;port=3306;';
$user_name = 'root';
$user_password = '';

$conn = new PDO($db_name, $user_name, $user_password);

?>